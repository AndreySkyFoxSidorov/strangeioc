using UnityEngine;
using System.Collections;

public enum EventGlobal
{
	E_None = 0,

	// Base mono events
	E_AppUpdate,
	E_AppFixedUpdate,
	E_AppLateUpdate,
    E_AppBackButton,
    E_AppApplicationFocus,
    //

    // Show/Hide universal Popup
    E_UIPopUpHide,
	E_UIPopUpShow,
    E_UICanvasPopUpShow,
    E_UICanvasPopUpHide,
    //

    // Show auto hide Text line
    E_ShowWarning,
	//

	// Only tests Window
	E_UITestWindowShow,
	E_UITestWindowHide,
    //

    //UI
    E_UICanvasHUDShow,
	E_UICanvasHUDHide,
	//

	//
	E_end
}
