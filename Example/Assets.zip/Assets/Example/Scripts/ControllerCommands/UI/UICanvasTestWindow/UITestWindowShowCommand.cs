﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.api;

public class UITestWindowShowCommand : BaseCommand
{
	static public Canvas canvas = null;

	public override void Execute()
	{



		Object obj = GameObject.Find( "UICanvasTestWindow" );
		if( !obj )
		{
			////////////////////////////////////////////////////////////////////////////////////////////

			Object prefab = Resources.Load( "Prefabs/UI/UICanvasTestWindow", typeof( GameObject ) );
			if( !prefab )
			{
				Debug.LogError( "Resources.Load  prefab == NULL" );
			}
			else
			{
				GameObject clone = GameObject.Instantiate( prefab, Vector3.zero, Quaternion.identity ) as GameObject;
				clone.transform.position = Vector3.one;
				clone.name = "UICanvasTestWindow";
				canvas=clone.GetComponent<Canvas>();
				//
				GameObject cameraObject = getCamera();
				if( cameraObject != null )
				{
					Camera camera = cameraObject.GetComponent<Camera>();
					Canvas canvas = clone.GetComponent<Canvas>();
					if( canvas != null && camera != null )
					{
						canvas.renderMode = RenderMode.ScreenSpaceOverlay;
						canvas.worldCamera = camera;
						//canvas.sortingOrder = 0;
					}
					// if(canvas)
				}

				if( mediationBinder != null )
				{
					BaseView hudV = clone.GetComponent<BaseView>();
					if( hudV )
					{
						//mediationBinder.Trigger( strange.extensions.mediation.api.MediationEvent.AWAKE, hudV as IView );
					}
					else
					{
						Debug.LogError( "UICanvasTestWindow == NULL" );
					}
				}
			}
			////////////////////////////////////////////////////////////////////////////////////////////
		}
		else
		{
			if( canvas!=null )
			{
				canvas.enabled = true;
			}
			else
			{
				Debug.LogError( "canvas UICanvasTestWindow == NULL" );
			}
			//((GameObject)obj).GetComponent<Canvas>().enabled = true;
		}
		Debug.Log( "UICanvasTestWindow End" );
	}
}
