﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UICanvasCheckForHUDCommand : BaseCommand
{

    public override void Execute()
    {
		

		Object obj = GameObject.Find("UICanvasHUD");
		if (!obj)
		{
            Fail();
			Debug.LogError("GameObject.Find UICanvasHUD == NULL");
		}
		else
		{
            
		}

		Debug.Log("UICanvasCheckForHUDCommand");
    }
}
