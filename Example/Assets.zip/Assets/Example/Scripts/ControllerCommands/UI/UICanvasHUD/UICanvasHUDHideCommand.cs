﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.api;

public class UICanvasHUDHideCommand : BaseCommand
{
	public override void Execute()
	{

		Object obj = GameObject.Find( "UICanvasHUD" );
		if( !obj )
		{
			Debug.LogError( "GameObject.Find UICanvasHUD == NULL" );
		}
		else
		{
			( ( GameObject )obj ).GetComponent<Canvas>().enabled = false;
			GameObject.Destroy( obj );
			obj = null;
		}

		Debug.Log( "UICanvasHUDHideCommand" );

	}
}


