﻿using UnityEngine;
using System.Collections;


public class AppLoadCommand : BaseCommand
{
	public override void Execute()
	{
		Debug.Log("AppLoadCommand Execute");
		Screen.sleepTimeout = SleepTimeout.NeverSleep;

	}
}
