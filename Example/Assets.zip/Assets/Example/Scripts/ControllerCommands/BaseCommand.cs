﻿/*
 * @ name: BaseCommand for Strange IOC
 * @ author: Andrey Sidorov ( Sky-Fox ) https://linkedin.com/in/skyfox
 * @ All rights reserved / Todos los derechos reservados / Âñå ïðàâà ñîõðàíåíû
*/

using System;
using UnityEngine;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;
using strange.extensions.context.api;
using strange.extensions.dispatcher.eventdispatcher.api;
using strange.extensions.command.impl;
using strange.extensions.pool.api;
using strange.extensions.mediation.api;
using strange.extensions.mediation.impl;

public class BaseCommand : Command
{
	[Inject]
	public IMediationBinder mediationBinder { get; private set; }


	[Inject]
	public ILocalization texts { get; private set; }


	[Inject(ContextKeys.CONTEXT_DISPATCHER)]
	public IEventDispatcher dispatcher { get; set; }


	[Inject]
	public IEvent eventData { get; set; }

	[Inject]
	public IExecutor coroutine { get; set; }


	public override void Retain()
	{
		base.Retain();
	}

	public override void Release()
	{
		base.Release();
	}


	public GameObject getCamera()
	{
		GameObject CameraObject = null;
		if(Camera.main != null && Camera.main.gameObject != null)
		{
			CameraObject = Camera.main.gameObject;
		}

		if(CameraObject == null)
		{
			foreach(var camera in GameObject.FindObjectsOfType(typeof(Camera)) as Camera[])
			{
				if(camera != null && camera.gameObject != null)
				{
					CameraObject = camera.gameObject;
					break;
				}
			}
		}
		if(CameraObject == null)
		{
			Debug.LogError("CameraObject = null");
		}
		return CameraObject;
	}
}

