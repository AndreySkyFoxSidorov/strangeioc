﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using strange.extensions.command.api;
using strange.extensions.command.impl;
using strange.extensions.context.api;
using strange.extensions.context.impl;
using strange.extensions.mediation.api;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.impl;
using strange.extensions.dispatcher.eventdispatcher.api;
using UnityEngine.EventSystems;

///////////////////
/// In this class, we treat all Input(Keyboard,mouse,Touch...) Events 

public class MainContextInput   : MainContextRoot
{
	public void OnApplicationFocus(bool focus)
    {
        if (dispatcher != null)
        {
            dispatcher.Dispatch(EventGlobal.E_AppApplicationFocus, focus);
        }
        else
        {
            Debug.LogError("FixedUpdate ERROR!!! dispatcher == null");
        }        
    }

	public MainContextInput(MonoBehaviour contextView):base(contextView)
	{
	}

	public override IContext Start()
	{
		IContext c =  base.Start();
		return c;
	}

	public void Update()
	{
		if(dispatcher != null)
		{
			// Android beack button
			if(Input.GetKeyDown(KeyCode.Escape))
			{
				dispatcher.Dispatch(EventGlobal.E_AppBackButton);
			}
			//

		}
		else
		{            
            Debug.LogError("Update ERROR!!! dispatcher == null");
		}
	}

	public void FixedUpdate()
	{
		if(dispatcher != null)
		{
            dispatcher.Dispatch(EventGlobal.E_AppFixedUpdate);
        }
        else
		{
			Debug.LogError("FixedUpdate ERROR!!! dispatcher == null");
		}
	}

	public void LateUpdate()
	{
		if(dispatcher != null)
		{
            dispatcher.Dispatch(EventGlobal.E_AppLateUpdate);
        }
        else
		{
			Debug.LogError("LateUpdate ERROR!!! dispatcher == null");
		}
	}
    
	//////
}
