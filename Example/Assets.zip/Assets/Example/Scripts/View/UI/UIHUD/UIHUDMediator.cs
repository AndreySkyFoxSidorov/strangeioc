﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;

public class UIHUDMediator : BaseMediator
{
	[Inject]
	public UIHUDView view { get; set; }

	public override void PreRegister()
	{

	}
	public override void OnRegister()
	{
		view.LoadView();
	}

	public override void OnRemove()
	{
		view.RemoveView();
	}

	public override void onAppBackButton()
	{
		Debug.Log("Escape Key EVENT UIHUDMediator");
		view.OnBack();
	}

}
