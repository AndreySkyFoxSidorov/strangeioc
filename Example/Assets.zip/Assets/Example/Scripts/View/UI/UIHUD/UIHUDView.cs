﻿
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;


public class UIHUDView : BaseView
{

	public void LoadView()
	{
	}


	public void RemoveView()
	{
		Debug.Log("HUD RemoveView ");
	}

	public void OnBack()
	{

	}



	private void Update()
	{
	}


}
