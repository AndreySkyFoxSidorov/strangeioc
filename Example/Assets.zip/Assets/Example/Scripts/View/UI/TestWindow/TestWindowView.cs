﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Events;


public class TestWindowView : BaseView
{
    public void LoadView()
    {
    }

    public void RemoveView()
    {
        Debug.Log("Remove TestWindowView");
    }



    private void Update()
    {
    }

}