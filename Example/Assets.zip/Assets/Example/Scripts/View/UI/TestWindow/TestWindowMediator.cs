﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class TestWindowMediator : BaseMediator
{
	[Inject]
	public TestWindowView view { get; private set; }


	public override void PreRegister()
	{
		Debug.Log("TestWindowMediator PreRegister");
	}
	public override void OnRegister()
	{
		Debug.Log("TestWindowMediator OnRegister");
		view.LoadView();
	}

	public override void OnRemove()
	{
		Debug.Log("TestWindowMediator OnRemove");
		if(dispatcher != null)
		{
		}
		if(view != null)
		{
			view.RemoveView();
		}
	}

}
