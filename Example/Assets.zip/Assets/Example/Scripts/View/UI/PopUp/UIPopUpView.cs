﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;
using UnityEngine.UI;
using System.Text.RegularExpressions;

public class UIPopUpView : BaseView
{
	public Text YesButton;
	public Text NoButton;
	public Text OkButton;

	public Text title;
	public Text description;
	public Text description2;
	public Text InputFieldText;
	public Text InputFieldPlaceholder;
	public Text error;
	public Image icon;

	public GameObject YesButtonGO;
	public GameObject NoButtonGO;
	public GameObject OkButtonGO;
	public GameObject CloseButtonGO;

	public GameObject titleGO;
	public GameObject descriptionGO;
	public GameObject InputFieldTextGO;
	public GameObject InputFieldPlaceholderGO;
	public GameObject IconGO;
	public GameObject description2GO;

	private bool showHud;

	public void LoadView()
	{
		Debug.Log("LoadView PopUpView");

		InputFieldTextGO.GetComponent<InputField>().onValueChanged.AddListener((Result)=>
		{
			error.text = "";
		});


		/////////////////////AutogenerateName
		int name_num = 1;
		while(ChackName("Character " + name_num))
		{
			name_num++;
		}
		InputFieldTextGO.GetComponent<InputField>().text = "Character " + name_num;
		////////////////////////

		if(YesButtonGO != null)
		{
			//YesButtonGO.GetComponent<Button>().onClick.RemoveAllListeners();
			//YesButtonGO.GetComponent<Button>().onClick.AddListener(this.OnYesButtonGO);
			YesButtonGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -YesButtonGO - NULL");
		}
		if(NoButtonGO != null)
		{
			//NoButtonGO.GetComponent<Button>().onClick.RemoveAllListeners();
			//NoButtonGO.GetComponent<Button>().onClick.AddListener(this.OnNoButtonGO);
			NoButtonGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -NoButtonGO - NULL");
		}
		if(OkButtonGO != null)
		{
			//OkButtonGO.GetComponent<Button>().onClick.RemoveAllListeners();
			//OkButtonGO.GetComponent<Button>().onClick.AddListener(this.OnOkButtonGO);
			OkButtonGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -OkButtonGO - NULL");
		}
		if(CloseButtonGO != null)
		{
			//CloseButtonGO.GetComponent<Button>().onClick.RemoveAllListeners();
			//CloseButtonGO.GetComponent<Button>().onClick.AddListener(this.OnCloseButtonGO);
			CloseButtonGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -CloseButtonGO - NULL");
		}
		if(titleGO != null)
		{
			titleGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -titleGO - NULL");
		}
		if(descriptionGO != null)
		{
			descriptionGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -descriptionGO - NULL");
		}
		if(InputFieldTextGO != null)
		{
			InputFieldTextGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -InputFieldTextGO - NULL");
		}
		if(InputFieldPlaceholderGO != null)
		{
			InputFieldPlaceholderGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
		}

		if(description2GO != null)
		{
			description2GO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -DescriptionGO - NULL");
		}

		if(IconGO != null)
		{
			IconGO.SetActive(false);
		}
		else
		{
			Debug.Log("PopUpView -IconGO - NULL");
		}

	}

	PopUpModel m_popUpModel = null;
	public void InitPopUp(PopUpModel popUpModel)
	{
		m_popUpModel = popUpModel;
		if(m_popUpModel == null)
		{
			Debug.LogError("PopUpView popUpModel == NULL");
			return;
		}
		Debug.Log("InitPopUp PopUpView");

		showHud = popUpModel.showHud;

		switch(popUpModel.type)
		{
		case PopUpModel.PopUpType.PopUpEditBox:
			{
				Debug.Log("PopUpView PopUpEditBox");
				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}
				if(description2GO != null)
				{
					description2GO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		case PopUpModel.PopUpType.PopUpOk:
			{
				Debug.Log("PopUpView PopUpOk");
				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}
				if(description2GO != null)
				{
					description2GO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		case PopUpModel.PopUpType.PopUpYesNo:
			{
				Debug.Log("PopUpView PopUpYesNo");

				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}
				if(description2GO != null)
				{
					description2GO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		case PopUpModel.PopUpType.PopUpWarning:
			{
				Debug.Log("PopUpView PopUpWarning");
				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}

				if(description2GO != null)
				{
					description2GO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		case PopUpModel.PopUpType.PopUpIconYesNo:
			{
				Debug.Log("PopUpView PopUpIcon");

				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}
				if(description2GO != null)
				{
					description2GO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		case PopUpModel.PopUpType.PopUpIconOk:
			{
				Debug.Log("PopUpView PopUpIcon");

				if(YesButtonGO != null)
				{
					YesButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -YesButtonGO - NULL");
				}
				if(NoButtonGO != null)
				{
					NoButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -NoButtonGO - NULL");
				}
				if(OkButtonGO != null)
				{
					OkButtonGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -OkButtonGO - NULL");
				}
				if(CloseButtonGO != null)
				{
					CloseButtonGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -CloseButtonGO - NULL");
				}

				if(titleGO != null)
				{
					titleGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -titleGO - NULL");
				}
				if(descriptionGO != null)
				{
					descriptionGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -descriptionGO - NULL");
				}
				if(InputFieldTextGO != null)
				{
					InputFieldTextGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldTextGO - NULL");
				}
				if(InputFieldPlaceholderGO != null)
				{
					InputFieldPlaceholderGO.SetActive(false);
				}
				else
				{
					Debug.Log("PopUpView -InputFieldPlaceholderGO - NULL");
				}
				if(description2GO != null)
				{
					description2GO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -DescriptionGO - NULL");
				}

				if(IconGO != null)
				{
					IconGO.SetActive(true);
				}
				else
				{
					Debug.Log("PopUpView -IconGO - NULL");
				}
			}
			break;
		}
		if(texts != null)
		{
			if(YesButtonGO.activeSelf && YesButton != null && YesButton.text != null)
			{
				YesButton.text = texts.GetText("button.yes");
			}
			if(NoButtonGO.activeSelf && NoButton != null && NoButton.text != null)
			{
				NoButton.text = texts.GetText("button.no");
			}
			if(OkButtonGO.activeSelf && OkButton != null && OkButton.text != null)
			{
				OkButton.text = texts.GetText("button.ok");
			}
		}
		if(titleGO.activeSelf && title != null)
		{
			title.text = m_popUpModel.title;
		}
		if(descriptionGO.activeSelf && description != null)
		{
			description.text = m_popUpModel.description;
		}

		if(InputFieldPlaceholderGO.activeSelf && InputFieldPlaceholder != null)
		{
			InputFieldPlaceholder.text = m_popUpModel.description;
		}
		if(description2GO.activeSelf && description2 != null)
		{
			description2.text = m_popUpModel.description;
		}
		if(IconGO.activeSelf && icon != null)
		{
			icon.sprite = m_popUpModel.icon;
			icon.color = m_popUpModel.color;
		}
	}

	public void OnYesButtonGO()
	{
		if(m_popUpModel != null && m_popUpModel.type == PopUpModel.PopUpType.PopUpEditBox)
		{
			// InputFieldTextGO.GetComponent<InputField>().text = Regex.Replace(InputFieldText.text, @"[^a-zA-Z0-9]+", "");

			if(InputFieldText.text == null || InputFieldText.text == "" || InputFieldText.text.ToCharArray().Length > 16 || InputFieldText.text.ToCharArray().Length < 2)
			{

				error.text = texts.GetText("ui.characterLimit");
				error.enabled = true;
				//if(Regex.Replace(InputFieldText.text, @"[^a-zA-Z0-9]+", ""))
				return;
			}
			else
			{

				if(ChackName(InputFieldText.text))
				{
					error.text = texts.GetText("ui.charNameExist");
					error.enabled = true;
					return;
				}
			}
		}
		OnCloseButton();
		if(m_popUpModel != null && m_popUpModel.delegateAction != null)
		{
			m_popUpModel.delegateAction(new PopUpReturnModel(PopUpReturnModel.PopUpReturn.PopUpPressYes, InputFieldText.text, showHud));
		}

	}
	public void OnNoButtonGO()
	{
		if(m_popUpModel != null && m_popUpModel.delegateAction != null)
		{
			m_popUpModel.delegateAction(new PopUpReturnModel(PopUpReturnModel.PopUpReturn.PopUpPressNo, InputFieldText.text, showHud));
		}
		OnCloseButton();
	}
	public void OnOkButtonGO()
	{
		if(m_popUpModel.type == PopUpModel.PopUpType.PopUpEditBox)
		{
			if(InputFieldText.text == null || InputFieldText.text == "")
			{
				return;
			}

		}
		OnCloseButtonGO();
	}
	public void OnCloseButtonGO()
	{
		if(m_popUpModel != null && m_popUpModel.delegateAction != null)
		{
			m_popUpModel.delegateAction(new PopUpReturnModel(PopUpReturnModel.PopUpReturn.PopUpPressOk, InputFieldText.text, showHud));
		}
		OnCloseButton();
	}

	public void OnCloseButton()
	{
		dispatcher.Dispatch(EventGlobal.E_UIPopUpHide);
	}

	public void onAppBackButton()
	{
		if(m_popUpModel == null)
		{
			OnCloseButton();
		}
		else if(m_popUpModel.type == PopUpModel.PopUpType.PopUpYesNo)
		{
			OnNoButtonGO();
		}
		else
		{
			OnOkButtonGO();
		}
	}
	public void RemoveView()
	{
		Debug.Log("RemoveView PopUpView");
	}

	public void Update()
	{
		//InputFieldTextGO.GetComponent<InputField>().text = Regex.Replace(InputFieldText.text, @"[^a-zA-Z0-9]+", "");
	}

	bool ChackName(string name)
	{
		bool nameExist = false;
		return nameExist;
	}

}



