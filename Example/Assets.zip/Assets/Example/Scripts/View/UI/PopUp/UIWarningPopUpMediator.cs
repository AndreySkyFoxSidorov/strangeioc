﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class UIWarningPopUpMediator : BaseMediator
{
	[Inject]
	public UIWarningPopUpView view { get; set; }

	public override void PreRegister()
	{
		Debug.Log("WarningPopUpMediator PreRegister");
	}
	public override void OnRegister()
	{
		Debug.Log("WarningPopUpMediator OnRegister");
		view.LoadView();
	}
	public override void OnRemove()
	{
		Debug.Log("WarningPopUpMediator OnRemove");
		view.RemoveView();
	}
	public override void onAppBackButton()
	{
		view.onAppBackButton();
	}
}
