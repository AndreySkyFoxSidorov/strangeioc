﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;
using UnityEngine.UI;


public class UIWarningPopUpView : BaseView
{

	public GameObject description;

	public float AlfaSpeed = 0.35f;
	public float MoveSpeed = 90.0f;
	public Vector3 GoToPosition = new Vector3(0, 2000, 0);

	public void LoadView()
	{
		Debug.Log("LoadView WarningPopUpView");
	}

	WarningPopUpModel m_popUpModel = null;
	public void InitWarningPopUp(WarningPopUpModel popUpModel)
	{
		m_popUpModel = popUpModel;
		alfa = 1;
	}

	float alfa=1;

	public void onAppBackButton()
	{
	}

	public void RemoveView()
	{
	}

	public void Update()
	{
		if(description != null && m_popUpModel!=null)
		{
			Text t = description.GetComponent<Text>();
			if(t != null)
			{
				t.text = m_popUpModel.description;
				t.color = new Color(m_popUpModel.colorText.r, m_popUpModel.colorText.g, m_popUpModel.colorText.b, alfa);

			}

			Outline o = description.GetComponent<Outline>();
			if(o != null)
			{
				o.effectColor = new Color(m_popUpModel.colorOutLine.r, m_popUpModel.colorOutLine.g, m_popUpModel.colorOutLine.b, alfa);
			}
			description.SetActive(true);


			description.transform.localPosition = Vector3.MoveTowards(description.transform.localPosition, GoToPosition, Time.deltaTime * MoveSpeed);
			alfa -= (Time.deltaTime * AlfaSpeed);

			if(alfa < 0)
			{
				Destroy(gameObject);
			}
		}
	}
}



