﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class UIPopUpMediator : BaseMediator
{
	[Inject]
	public UIPopUpView view { get; set; }

	public override void PreRegister()
	{
		Debug.Log("PopUpMediator PreRegister");
	}
	public override void OnRegister()
	{
		Debug.Log("PopUpMediator OnRegister");
		view.LoadView();
	}
	public override void OnRemove()
	{
		Debug.Log("PopUpMediator OnRemove");
		view.RemoveView();
	}
	public override void onAppBackButton()
	{
		view.onAppBackButton();
	}
}
