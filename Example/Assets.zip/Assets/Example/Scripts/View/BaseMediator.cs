﻿using System;
using strange.extensions.context.api;
using strange.extensions.dispatcher.eventdispatcher.api;
using UnityEngine;

namespace strange.extensions.mediation.impl
{
public class BaseMediator : Mediator
{
	[Inject(ContextKeys.CONTEXT_DISPATCHER)]
	public IEventDispatcher dispatcher { get; set; }

	[Inject]
	public ILocalization texts { get; private set; }

	protected bool wasHidden = false;
	private bool wasUnregistered = true;

	public void Disable()
	{
		wasHidden = true;
		OnSleep();

	}


	private void Start()
	{
		if(dispatcher != null)
		{
            Debug.Log("Escape Key EVENT dispatcher RemoveListener");
			dispatcher.AddListener(EventGlobal.E_AppBackButton, onAppBackButton);
		}
		else
		{
			Debug.Log("Escape Key EVENT AddListenerStrangeEvent RemoveListener");
			MainContextView.AddListenerStrangeEvent(EventGlobal.E_AppBackButton, onAppBackButton);
		}
	}

	private void OnDestroy()
	{

		if(dispatcher != null)
		{
			Debug.Log("Escape Key EVENT dispatcher RemoveListener");
			dispatcher.RemoveListener(EventGlobal.E_AppBackButton, onAppBackButton);
		}
		else
		{
			Debug.Log("Escape Key EVENT RemoveListenerStrangeEvent RemoveListener");
			MainContextView.RemoveListenerStrangeEvent(EventGlobal.E_AppBackButton, onAppBackButton);
		}
	}

	public virtual void onAppBackButton()
	{
		Debug.Log("Escape Key EVENT BaseMediator");
	}


	public override void OnRegister()
	{
		base.OnRegister();
		wasUnregistered = false;

	}

	public override void OnRemove()
	{
		base.OnRemove();
		wasUnregistered = true;
	}

	protected virtual void OnEnabled()
	{
		OnRegister();
	}
	protected virtual void OnSleep()
	{

	}
	public void Enable()
	{
		if(wasHidden)
		{
			OnEnabled();
			wasHidden = false;
		}
	}

}
}