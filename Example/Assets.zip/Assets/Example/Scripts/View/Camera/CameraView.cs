﻿﻿using UnityEngine;
using System.Collections;


public class CameraView : BaseView
{
	private Camera m_camera;

	public void LoadView()
	{

		if(m_camera == null)
		{
			m_camera = gameObject.GetComponent<Camera>();
		}

        Debug.Log("Init CameraView");
	}

	public void RemoveView()
	{
        Debug.Log("Remove CameraView");
	}



}