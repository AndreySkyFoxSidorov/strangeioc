﻿using UnityEngine;
using System.Collections;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class CameraMediator : BaseMediator
{
	[Inject]
	public CameraView view { get; private set; }


	public override void PreRegister()
	{
		Debug.Log("CameraMediator PreRegister");
	}
	public override void OnRegister()
	{
        Debug.Log("CameraMediator OnRegister");
		view.LoadView();
	}

	public override void OnRemove()
	{
        Debug.Log("CameraMediator OnRemove");
		if(view != null)
		{
			view.RemoveView();
		}
	}

}
