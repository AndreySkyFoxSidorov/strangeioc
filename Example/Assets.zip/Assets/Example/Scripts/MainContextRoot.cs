﻿using UnityEngine;
using System.Collections;
using strange.extensions.command.api;
using strange.extensions.command.impl;
using strange.extensions.context.api;
using strange.extensions.context.impl;
using strange.extensions.mediation.api;
using strange.extensions.mediation.impl;
using strange.extensions.dispatcher.eventdispatcher.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class MainContextRoot : MVCSContext
{
	public MainContextRoot(MonoBehaviour contextView):base(contextView,ContextStartupFlags.MANUAL_MAPPING)
	{
	}

	// CoreComponents
	protected override void addCoreComponents()
	{
        // Inject CoreComponents
        base.addCoreComponents();

        // Inject CoroutineExecutor for Use Start Corutine in Strange Context
        injectionBinder.Bind<IExecutor>().To<CoroutineExecutor>().ToSingleton();

        // Inject LocalizationManager for TRANSLETE text in UI
        injectionBinder.Bind<ILocalization>().To<LocalizationManager>().ToSingleton();
    }

    // Commands and Bindings and Mediators
    protected override void mapBindings()
	{
		base.mapBindings();

        // Adding Camera Control
        Camera.main.gameObject.AddComponent<CameraView>();
		mediationBinder.BindView<CameraView>().ToMediator<CameraMediator>();
        //

        // Example TestWindow 
        mediationBinder.BindView<TestWindowView>().ToMediator<TestWindowMediator>();
        commandBinder.Bind(EventGlobal.E_UITestWindowShow).To<UITestWindowShowCommand>().Pooled();
        commandBinder.Bind(EventGlobal.E_UITestWindowHide).To<UITestWindowHideCommand>().Pooled();

        //

        // Example HUD
        mediationBinder.BindView<UIHUDView>().ToMediator<UIHUDMediator>();
        commandBinder.Bind(EventGlobal.E_UICanvasHUDShow).To<UICanvasHUDShowCommand>().Pooled();
        commandBinder.Bind(EventGlobal.E_UICanvasHUDHide).To<UICanvasHUDHideCommand>().Pooled();
        //

        // Example PopUp 
        mediationBinder.BindView<UIPopUpView>().ToMediator<UIPopUpMediator>();
        commandBinder.Bind(EventGlobal.E_UICanvasPopUpShow).To<UICanvasPopUpShowCommand>().Pooled();
        commandBinder.Bind(EventGlobal.E_UICanvasPopUpHide).To<UICanvasPopUpHideCommand>().Pooled();
        commandBinder.Bind(EventGlobal.E_UIPopUpShow).To<UICanvasPopUpShowCommand>().Pooled();
        commandBinder.Bind(EventGlobal.E_UIPopUpHide).To<UICanvasPopUpHideCommand>().Pooled();

        //

        // System Commands
        commandBinder.Bind(ContextEvent.START)
		.To<AppLoadCommand>()
		.Pooled()
		.InSequence()
		.Once();
	}
}
