﻿using UnityEngine;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.Linq;
using System.IO;

public class LocalizationManager : ILocalization
{

	public LocalizationManager()
	{
	}

	public string GetText(string key)
	{
		string translation = key; // Find Localisation

		return translation;
	}




}