﻿using UnityEngine;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using System.IO;

public interface ILocalization
{
	string GetText(string key);
}