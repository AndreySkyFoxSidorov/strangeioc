﻿using UnityEngine;
using System.Collections;

public class PopUpReturnModel
{
	public enum PopUpReturn
	{
		PopUpPressOk,
		PopUpPressYes,
		PopUpPressNo,
	}
	public PopUpReturnModel(PopUpReturn _status, string _text, bool _showHud)
	{
		status = _status;
		text = _text;
		showHUD = _showHud;
	}
	public PopUpReturn status = PopUpReturn.PopUpPressOk;
	public string text = "";
	public bool showHUD = true;
}

public class PopUpModel
{
	public enum PopUpType
	{
		PopUpWarning,
		PopUpOk,
		PopUpYesNo,
		PopUpEditBox,
		PopUpIconYesNo,
		PopUpIconOk
	}


	public PopUpType type = PopUpType.PopUpWarning;
	public string title = "test title";
	public string description = "test description";
	public System.Action<PopUpReturnModel> delegateAction = null;
	public bool showHud = true;
	public Sprite icon = null;
	public Color color = new Color();

	public PopUpModel(PopUpType _type, string _title, string _description, System.Action<PopUpReturnModel> action, Sprite _icon = null, Color _color = new Color() , bool _showHud = true)
	{
		type = _type;
		title = _title;
		description = _description;
		delegateAction = action;
		showHud = _showHud;
		icon = _icon;

		if(_color.a == 0)
		{
			color = Color.white;
		}
		else
		{
			color = _color;
		}
	}


}