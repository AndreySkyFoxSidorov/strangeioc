using UnityEngine;
using System.Collections;

public static class RateUsModel
{

	public static bool isFirstLaunch = true;

	public static bool animationLaunchWasSuccessful = false;
}
