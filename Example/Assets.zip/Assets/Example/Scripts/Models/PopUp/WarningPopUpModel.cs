﻿using UnityEngine;
using System.Collections;


public class WarningPopUpModel
{
	public string description = "test description";
	public Color colorText = Color.red;
	public Color colorOutLine = Color.white;

	public WarningPopUpModel(string _description, Color _colorText, Color _colorOutline)
	{
		colorText = _colorText;
		colorOutLine = _colorOutline;
		description = _description;
	}

	public WarningPopUpModel(string _description)
	{
		description = _description;
	}
}